# Changelog

## 0.1.0 - 2026-07-20

- Included OpenFracture 1.0.2 source with Unity 6 Rigidbody API compatibility changes.
- Added localized impact destruction.
- Added precomputed structural support graph collapse.
- Added generic partition authoring and fragment generation tools.
- Added the breakable partition sample scene.
