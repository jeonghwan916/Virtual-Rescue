# Breakable Partition Demo

`BreakablePartitionDemo.unity` contains a 6 x 6 x 1 thin wall fractured into 36 pieces.

- Move and aim with the camera controls shown in the Game view.
- Fire the projectile at different points to verify localized release.
- Remove a supported region and verify disconnected fragments collapse.

The scene uses OpenFracture's legacy-input demo controller. Set **Active Input Handling** to **Both** or **Input Manager (Old)** when testing this sample.
