using UnityEngine;

namespace VirtualRescue.Destruction
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer), typeof(Rigidbody))]
    public sealed class BreakablePartitionAuthoring : MonoBehaviour
    {
        [Header("Fracture")]
        [SerializeField, Range(2, 1024)] private int _fragmentCount = 36;
        [SerializeField] private bool _fractureXAxis = true;
        [SerializeField] private bool _fractureYAxis = true;
        [SerializeField] private bool _fractureZAxis;
        [SerializeField] private bool _detectFloatingFragments;
        [SerializeField] private Material _insideMaterial;
        [SerializeField] private Vector2 _textureScale = new Vector2(0.1f, 0.1f);
        [SerializeField] private Vector2 _textureOffset;
        [SerializeField] private bool _saveFragmentMeshes = true;
        [SerializeField] private string _meshOutputFolder = "Assets/Generated/BreakablePartitions";

        [Header("Impact Filter")]
        [SerializeField] private string _allowedTag = "Projectile";
        [SerializeField, Min(0f)] private float _minimumCollisionForce;
        [SerializeField, Min(0f)] private float _impactCooldown = 0.08f;

        [Header("Localized Destruction")]
        [SerializeField, Min(0.01f)] private float _destructionRadius = 1.25f;
        [SerializeField, Min(0f)] private float _directHitRadius = 0.35f;
        [SerializeField, Min(0f)] private float _impulseMultiplier = 0.08f;

        [Header("Support Graph")]
        [SerializeField, Min(0.0001f)] private float _vertexTolerance = 0.002f;
        [SerializeField, Min(2)] private int _minimumSharedVertices = 3;
        [SerializeField, Min(0f)] private float _anchorMargin = 0.08f;
        [SerializeField] private bool _anchorLeft = true;
        [SerializeField] private bool _anchorRight = true;
        [SerializeField] private bool _anchorTop = true;
        [SerializeField] private bool _anchorBottom = true;
        [SerializeField, Min(0f)] private float _collapseDelay = 0.15f;
        [SerializeField, Min(0f)] private float _randomCollapseDelay = 0.1f;
        [SerializeField, Min(0f)] private float _downwardImpulse = 0.25f;

        [SerializeField, HideInInspector] private GameObject _generatedRoot;

        public int FragmentCount => _fragmentCount;
        public bool FractureXAxis => _fractureXAxis;
        public bool FractureYAxis => _fractureYAxis;
        public bool FractureZAxis => _fractureZAxis;
        public bool DetectFloatingFragments => _detectFloatingFragments;
        public Material InsideMaterial => _insideMaterial;
        public Vector2 TextureScale => _textureScale;
        public Vector2 TextureOffset => _textureOffset;
        public bool SaveFragmentMeshes => _saveFragmentMeshes;
        public string MeshOutputFolder => _meshOutputFolder;
        public string AllowedTag => _allowedTag;
        public float MinimumCollisionForce => _minimumCollisionForce;
        public float ImpactCooldown => _impactCooldown;
        public float DestructionRadius => _destructionRadius;
        public float DirectHitRadius => _directHitRadius;
        public float ImpulseMultiplier => _impulseMultiplier;
        public float VertexTolerance => _vertexTolerance;
        public int MinimumSharedVertices => _minimumSharedVertices;
        public float AnchorMargin => _anchorMargin;
        public bool AnchorLeft => _anchorLeft;
        public bool AnchorRight => _anchorRight;
        public bool AnchorTop => _anchorTop;
        public bool AnchorBottom => _anchorBottom;
        public float CollapseDelay => _collapseDelay;
        public float RandomCollapseDelay => _randomCollapseDelay;
        public float DownwardImpulse => _downwardImpulse;
        public GameObject GeneratedRoot => _generatedRoot;

        private void OnValidate()
        {
            _fragmentCount = Mathf.Clamp(_fragmentCount, 2, 1024);
            _destructionRadius = Mathf.Max(0.01f, _destructionRadius);
            _directHitRadius = Mathf.Clamp(_directHitRadius, 0f, _destructionRadius);
            _minimumCollisionForce = Mathf.Max(0f, _minimumCollisionForce);
            _impactCooldown = Mathf.Max(0f, _impactCooldown);
            _impulseMultiplier = Mathf.Max(0f, _impulseMultiplier);
            _vertexTolerance = Mathf.Max(0.0001f, _vertexTolerance);
            _minimumSharedVertices = Mathf.Max(2, _minimumSharedVertices);
            _anchorMargin = Mathf.Max(0f, _anchorMargin);
            _collapseDelay = Mathf.Max(0f, _collapseDelay);
            _randomCollapseDelay = Mathf.Max(0f, _randomCollapseDelay);
            _downwardImpulse = Mathf.Max(0f, _downwardImpulse);
        }

        public void SetGeneratedRoot(GameObject generatedRoot)
        {
            _generatedRoot = generatedRoot;
        }
    }
}
