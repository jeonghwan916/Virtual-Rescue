using UnityEngine;

namespace VirtualRescue.Destruction
{
    [DisallowMultipleComponent]
    public sealed class LocalizedFractureController : MonoBehaviour
    {
        [Header("Impact Filter")]
        [SerializeField] private string _allowedTag = "Projectile";
        [SerializeField, Min(0f)] private float _minimumCollisionForce;
        [SerializeField, Min(0f)] private float _impactCooldown = 0.08f;

        [Header("Localized Destruction")]
        [SerializeField, Min(0.01f)] private float _destructionRadius = 1.25f;
        [SerializeField, Min(0f)] private float _directHitRadius = 0.35f;
        [SerializeField, Min(0f)] private float _impulseMultiplier = 0.08f;
        [SerializeField, Range(0f, 1f)] private float _radialDirectionWeight = 0.35f;
        [SerializeField, Range(0f, 1f)] private float _edgeImpulseRatio = 0.2f;
        [SerializeField] private bool _logImpacts;

        private LocalizedFracturePiece[] _pieces;
        private FractureSupportGraph _supportGraph;
        private int _lastInstigatorId;
        private float _lastImpactTime = float.NegativeInfinity;
        private Vector3 _lastImpactPoint;
        private bool _hasImpactPoint;

        private void Awake()
        {
            _supportGraph = GetComponent<FractureSupportGraph>();
            RefreshPieces();
        }

        private void OnValidate()
        {
            _destructionRadius = Mathf.Max(0.01f, _destructionRadius);
            _directHitRadius = Mathf.Clamp(_directHitRadius, 0f, _destructionRadius);
            _minimumCollisionForce = Mathf.Max(0f, _minimumCollisionForce);
            _impactCooldown = Mathf.Max(0f, _impactCooldown);
            _impulseMultiplier = Mathf.Max(0f, _impulseMultiplier);
        }

        private void OnDrawGizmosSelected()
        {
            if (!_hasImpactPoint)
            {
                return;
            }

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(_lastImpactPoint, _destructionRadius);
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(_lastImpactPoint, _directHitRadius);
        }

        public void Configure(
            string allowedTag,
            float destructionRadius,
            float directHitRadius,
            float impulseMultiplier,
            float minimumCollisionForce,
            float impactCooldown)
        {
            _destructionRadius = Mathf.Max(0.01f, destructionRadius);
            _directHitRadius = Mathf.Clamp(directHitRadius, 0f, _destructionRadius);
            _impulseMultiplier = Mathf.Max(0f, impulseMultiplier);
            _minimumCollisionForce = Mathf.Max(0f, minimumCollisionForce);
            _impactCooldown = Mathf.Max(0f, impactCooldown);
            _allowedTag = allowedTag;
        }

        public void RefreshPieces()
        {
            _pieces = GetComponentsInChildren<LocalizedFracturePiece>(true);
            foreach (LocalizedFracturePiece piece in _pieces)
            {
                piece.Initialize(this);
            }
        }

        public bool TryApplyImpact(LocalizedFracturePiece hitPiece, Collision collision)
        {
            if (hitPiece == null || collision == null || collision.contactCount == 0)
            {
                return false;
            }

            if (!string.IsNullOrEmpty(_allowedTag) && !collision.gameObject.CompareTag(_allowedTag))
            {
                return false;
            }

            int instigatorId = collision.collider.GetInstanceID();
            if (instigatorId == _lastInstigatorId && Time.time - _lastImpactTime < _impactCooldown)
            {
                return false;
            }

            float collisionForce = collision.impulse.magnitude / Mathf.Max(Time.fixedDeltaTime, 0.0001f);
            if (collisionForce < _minimumCollisionForce)
            {
                return false;
            }

            _lastInstigatorId = instigatorId;
            _lastImpactTime = Time.time;

            ContactPoint contact = collision.GetContact(0);
            Vector3 incomingDirection = GetIncomingDirection(collision, contact);
            float impactMagnitude = GetImpactMagnitude(collision);
            int releasedCount = ReleasePieces(contact.point, incomingDirection, impactMagnitude, hitPiece);

            if (releasedCount > 0)
            {
                _supportGraph?.EvaluateSupport();
            }

            if (_logImpacts)
            {
                Debug.Log(
                    $"Localized fracture released {releasedCount} piece(s) at {contact.point}.",
                    this);
            }

            return releasedCount > 0;
        }

        private int ReleasePieces(
            Vector3 impactPoint,
            Vector3 incomingDirection,
            float impactMagnitude,
            LocalizedFracturePiece hitPiece)
        {
            if (_pieces == null || _pieces.Length == 0)
            {
                RefreshPieces();
            }

            _lastImpactPoint = impactPoint;
            _hasImpactPoint = true;

            int releasedCount = 0;
            foreach (LocalizedFracturePiece piece in _pieces)
            {
                if (piece == null || piece.IsReleased || piece.FragmentCollider == null)
                {
                    continue;
                }

                Vector3 closestPoint = piece.FragmentCollider.ClosestPoint(impactPoint);
                float distance = Vector3.Distance(impactPoint, closestPoint);
                if (piece != hitPiece && distance > _destructionRadius)
                {
                    continue;
                }

                float normalizedDistance = Mathf.Clamp01(distance / _destructionRadius);
                float falloff = Mathf.Lerp(1f, _edgeImpulseRatio, normalizedDistance);
                if (piece == hitPiece || distance <= _directHitRadius)
                {
                    falloff = 1f;
                }

                Vector3 radialDirection = piece.FragmentCollider.bounds.center - impactPoint;
                if (radialDirection.sqrMagnitude < 0.0001f)
                {
                    radialDirection = incomingDirection;
                }

                radialDirection.Normalize();
                Vector3 impulseDirection = Vector3.Lerp(
                    incomingDirection,
                    radialDirection,
                    _radialDirectionWeight).normalized;

                Vector3 impulse = impulseDirection * impactMagnitude * _impulseMultiplier * falloff;
                piece.Release(impulse, impactPoint);
                releasedCount++;
            }

            return releasedCount;
        }

        private static Vector3 GetIncomingDirection(Collision collision, ContactPoint contact)
        {
            Rigidbody instigatorRigidbody = collision.rigidbody;
            Vector3 incomingDirection = instigatorRigidbody != null
                ? instigatorRigidbody.linearVelocity
                : collision.relativeVelocity;

            if (incomingDirection.sqrMagnitude < 0.0001f)
            {
                incomingDirection = -contact.normal;
            }

            return incomingDirection.normalized;
        }

        private static float GetImpactMagnitude(Collision collision)
        {
            float impactMagnitude = collision.impulse.magnitude;
            if (impactMagnitude > 0.0001f)
            {
                return impactMagnitude;
            }

            Rigidbody instigatorRigidbody = collision.rigidbody;
            float instigatorMass = instigatorRigidbody != null ? instigatorRigidbody.mass : 1f;
            return instigatorMass * collision.relativeVelocity.magnitude;
        }
    }
}
