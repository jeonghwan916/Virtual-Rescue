using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VirtualRescue.Destruction
{
    [DisallowMultipleComponent]
    public sealed class FractureSupportGraph : MonoBehaviour
    {
        private const int CurrentGraphVersion = 1;

        [Header("Graph Generation")]
        [SerializeField, Min(0.0001f)] private float _vertexTolerance = 0.002f;
        [SerializeField, Min(2)] private int _minimumSharedVertices = 3;
        [SerializeField, Min(0f)] private float _anchorMargin = 0.08f;

        [Header("Virtual Frame Anchors")]
        [SerializeField] private bool _anchorLeft = true;
        [SerializeField] private bool _anchorRight = true;
        [SerializeField] private bool _anchorTop = true;
        [SerializeField] private bool _anchorBottom = true;

        [Header("Unsupported Collapse")]
        [SerializeField, Min(0f)] private float _collapseDelay = 0.15f;
        [SerializeField, Min(0f)] private float _randomDelay = 0.1f;
        [SerializeField, Min(0f)] private float _downwardImpulse = 0.25f;
        [SerializeField] private bool _logGraphEvents;

        [SerializeField, HideInInspector] private int _serializedGraphVersion;
        [SerializeField, HideInInspector] private int _anchorCount;
        [SerializeField, HideInInspector] private int _connectionCount;

        private readonly HashSet<LocalizedFracturePiece> _supportedPieces = new HashSet<LocalizedFracturePiece>();
        private readonly Queue<LocalizedFracturePiece> _supportQueue = new Queue<LocalizedFracturePiece>();
        private readonly List<PendingCollapse> _pendingCollapses = new List<PendingCollapse>();

        private LocalizedFracturePiece[] _pieces;
        private Coroutine _collapseCoroutine;

        private void Awake()
        {
            RefreshPieces();
            if (_serializedGraphVersion != CurrentGraphVersion)
            {
                BuildGraph();
            }
        }

        private void OnDisable()
        {
            if (_collapseCoroutine != null)
            {
                StopCoroutine(_collapseCoroutine);
                _collapseCoroutine = null;
            }

            foreach (PendingCollapse pendingCollapse in _pendingCollapses)
            {
                pendingCollapse.Piece?.CancelScheduledCollapse();
            }

            _pendingCollapses.Clear();
        }

        private void OnValidate()
        {
            _vertexTolerance = Mathf.Max(0.0001f, _vertexTolerance);
            _minimumSharedVertices = Mathf.Max(2, _minimumSharedVertices);
            _anchorMargin = Mathf.Max(0f, _anchorMargin);
            _collapseDelay = Mathf.Max(0f, _collapseDelay);
            _randomDelay = Mathf.Max(0f, _randomDelay);
            _downwardImpulse = Mathf.Max(0f, _downwardImpulse);
        }

        public void Configure(
            float vertexTolerance,
            int minimumSharedVertices,
            float anchorMargin,
            bool anchorLeft,
            bool anchorRight,
            bool anchorTop,
            bool anchorBottom,
            float collapseDelay,
            float randomDelay,
            float downwardImpulse)
        {
            _vertexTolerance = Mathf.Max(0.0001f, vertexTolerance);
            _minimumSharedVertices = Mathf.Max(2, minimumSharedVertices);
            _anchorMargin = Mathf.Max(0f, anchorMargin);
            _anchorLeft = anchorLeft;
            _anchorRight = anchorRight;
            _anchorTop = anchorTop;
            _anchorBottom = anchorBottom;
            _collapseDelay = Mathf.Max(0f, collapseDelay);
            _randomDelay = Mathf.Max(0f, randomDelay);
            _downwardImpulse = Mathf.Max(0f, downwardImpulse);
        }

        [ContextMenu("Build Support Graph")]
        public void BuildGraph()
        {
            RefreshPieces();
            List<PieceGeometry> geometries = CreatePieceGeometries();
            if (geometries.Count == 0)
            {
                _serializedGraphVersion = 0;
                _anchorCount = 0;
                _connectionCount = 0;
                return;
            }

            Bounds wallBounds = geometries[0].Bounds;
            for (int i = 1; i < geometries.Count; i++)
            {
                wallBounds.Encapsulate(geometries[i].Bounds.min);
                wallBounds.Encapsulate(geometries[i].Bounds.max);
            }

            _anchorCount = 0;
            foreach (PieceGeometry geometry in geometries)
            {
                bool isAnchor = IsFrameAnchor(geometry.Bounds, wallBounds);
                geometry.Piece.ConfigureSupport(isAnchor);
                if (isAnchor)
                {
                    _anchorCount++;
                }
            }

            _connectionCount = 0;
            for (int i = 0; i < geometries.Count - 1; i++)
            {
                for (int j = i + 1; j < geometries.Count; j++)
                {
                    if (CountSharedVertices(geometries[i].Vertices, geometries[j].Vertices) < _minimumSharedVertices)
                    {
                        continue;
                    }

                    geometries[i].Piece.AddNeighbor(geometries[j].Piece);
                    geometries[j].Piece.AddNeighbor(geometries[i].Piece);
                    _connectionCount++;
                }
            }

            _serializedGraphVersion = CurrentGraphVersion;

            if (_logGraphEvents)
            {
                Debug.Log(
                    $"Support graph built with {_pieces.Length} pieces, {_anchorCount} anchors, and {_connectionCount} connections.",
                    this);
            }
        }

        public void EvaluateSupport()
        {
            RefreshPieces();
            _supportedPieces.Clear();
            _supportQueue.Clear();

            foreach (LocalizedFracturePiece piece in _pieces)
            {
                if (piece != null && piece.IsAnchor && piece.CanProvideSupport && _supportedPieces.Add(piece))
                {
                    _supportQueue.Enqueue(piece);
                }
            }

            while (_supportQueue.Count > 0)
            {
                LocalizedFracturePiece currentPiece = _supportQueue.Dequeue();
                foreach (LocalizedFracturePiece neighbor in currentPiece.Neighbors)
                {
                    if (neighbor == null || !neighbor.CanProvideSupport || !_supportedPieces.Add(neighbor))
                    {
                        continue;
                    }

                    _supportQueue.Enqueue(neighbor);
                }
            }

            int scheduledCount = 0;
            foreach (LocalizedFracturePiece piece in _pieces)
            {
                if (piece == null || !piece.CanProvideSupport || _supportedPieces.Contains(piece))
                {
                    continue;
                }

                if (!piece.ScheduleCollapse())
                {
                    continue;
                }

                float releaseTime = Time.time + _collapseDelay + UnityEngine.Random.Range(0f, _randomDelay);
                _pendingCollapses.Add(new PendingCollapse(piece, releaseTime));
                scheduledCount++;
            }

            if (_pendingCollapses.Count > 0 && _collapseCoroutine == null)
            {
                _collapseCoroutine = StartCoroutine(ProcessPendingCollapses());
            }

            if (_logGraphEvents && scheduledCount > 0)
            {
                Debug.Log($"Scheduled {scheduledCount} unsupported piece(s) for collapse.", this);
            }
        }

        private IEnumerator ProcessPendingCollapses()
        {
            while (_pendingCollapses.Count > 0)
            {
                for (int i = _pendingCollapses.Count - 1; i >= 0; i--)
                {
                    PendingCollapse pendingCollapse = _pendingCollapses[i];
                    if (pendingCollapse.Piece == null || pendingCollapse.Piece.IsReleased)
                    {
                        _pendingCollapses.RemoveAt(i);
                        continue;
                    }

                    if (Time.time < pendingCollapse.ReleaseTime)
                    {
                        continue;
                    }

                    Vector3 releasePoint = pendingCollapse.Piece.FragmentCollider != null
                        ? pendingCollapse.Piece.FragmentCollider.bounds.center
                        : pendingCollapse.Piece.transform.position;
                    pendingCollapse.Piece.Release(Vector3.down * _downwardImpulse, releasePoint);
                    _pendingCollapses.RemoveAt(i);
                }

                yield return null;
            }

            _collapseCoroutine = null;
        }

        private void RefreshPieces()
        {
            _pieces = GetComponentsInChildren<LocalizedFracturePiece>(true);
        }

        private List<PieceGeometry> CreatePieceGeometries()
        {
            var geometries = new List<PieceGeometry>(_pieces.Length);
            foreach (LocalizedFracturePiece piece in _pieces)
            {
                if (piece == null)
                {
                    continue;
                }

                MeshFilter meshFilter = piece.GetComponent<MeshFilter>();
                if (meshFilter == null || meshFilter.sharedMesh == null)
                {
                    continue;
                }

                Vector3[] vertices = meshFilter.sharedMesh.vertices;
                if (vertices.Length == 0)
                {
                    continue;
                }

                var vertexKeys = new HashSet<VertexKey>();
                Vector3 firstVertex = transform.InverseTransformPoint(meshFilter.transform.TransformPoint(vertices[0]));
                Bounds localBounds = new Bounds(firstVertex, Vector3.zero);

                foreach (Vector3 vertex in vertices)
                {
                    Vector3 localVertex = transform.InverseTransformPoint(meshFilter.transform.TransformPoint(vertex));
                    localBounds.Encapsulate(localVertex);
                    vertexKeys.Add(new VertexKey(localVertex, _vertexTolerance));
                }

                geometries.Add(new PieceGeometry(piece, vertexKeys, localBounds));
            }

            return geometries;
        }

        private bool IsFrameAnchor(Bounds pieceBounds, Bounds wallBounds)
        {
            bool touchesLeft = _anchorLeft && pieceBounds.min.x <= wallBounds.min.x + _anchorMargin;
            bool touchesRight = _anchorRight && pieceBounds.max.x >= wallBounds.max.x - _anchorMargin;
            bool touchesBottom = _anchorBottom && pieceBounds.min.y <= wallBounds.min.y + _anchorMargin;
            bool touchesTop = _anchorTop && pieceBounds.max.y >= wallBounds.max.y - _anchorMargin;
            return touchesLeft || touchesRight || touchesBottom || touchesTop;
        }

        private static int CountSharedVertices(HashSet<VertexKey> first, HashSet<VertexKey> second)
        {
            HashSet<VertexKey> smaller = first.Count <= second.Count ? first : second;
            HashSet<VertexKey> larger = first.Count <= second.Count ? second : first;

            int sharedCount = 0;
            foreach (VertexKey vertex in smaller)
            {
                if (larger.Contains(vertex))
                {
                    sharedCount++;
                }
            }

            return sharedCount;
        }

        private sealed class PieceGeometry
        {
            public PieceGeometry(
                LocalizedFracturePiece piece,
                HashSet<VertexKey> vertices,
                Bounds bounds)
            {
                Piece = piece;
                Vertices = vertices;
                Bounds = bounds;
            }

            public LocalizedFracturePiece Piece { get; }
            public HashSet<VertexKey> Vertices { get; }
            public Bounds Bounds { get; }
        }

        private readonly struct PendingCollapse
        {
            public PendingCollapse(LocalizedFracturePiece piece, float releaseTime)
            {
                Piece = piece;
                ReleaseTime = releaseTime;
            }

            public LocalizedFracturePiece Piece { get; }
            public float ReleaseTime { get; }
        }

        private readonly struct VertexKey : IEquatable<VertexKey>
        {
            private readonly int _x;
            private readonly int _y;
            private readonly int _z;

            public VertexKey(Vector3 vertex, float tolerance)
            {
                _x = Mathf.RoundToInt(vertex.x / tolerance);
                _y = Mathf.RoundToInt(vertex.y / tolerance);
                _z = Mathf.RoundToInt(vertex.z / tolerance);
            }

            public bool Equals(VertexKey other)
            {
                return _x == other._x && _y == other._y && _z == other._z;
            }

            public override bool Equals(object obj)
            {
                return obj is VertexKey other && Equals(other);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    int hashCode = _x;
                    hashCode = (hashCode * 397) ^ _y;
                    hashCode = (hashCode * 397) ^ _z;
                    return hashCode;
                }
            }
        }
    }
}
