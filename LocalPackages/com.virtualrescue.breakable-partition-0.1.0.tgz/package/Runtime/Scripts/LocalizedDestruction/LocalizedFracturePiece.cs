using System.Collections.Generic;
using UnityEngine;

namespace VirtualRescue.Destruction
{
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Rigidbody))]
    [RequireComponent(typeof(Collider))]
    public sealed class LocalizedFracturePiece : MonoBehaviour
    {
        [SerializeField] private LocalizedFractureController _controller;
        [SerializeField] private bool _isAnchor;
        [SerializeField] private List<LocalizedFracturePiece> _neighbors = new List<LocalizedFracturePiece>();

        private Rigidbody _rigidbody;
        private Collider _fragmentCollider;

        public Collider FragmentCollider => _fragmentCollider;
        public IReadOnlyList<LocalizedFracturePiece> Neighbors => _neighbors;
        public bool IsAnchor => _isAnchor;
        public bool IsReleased { get; private set; }
        public bool IsCollapseScheduled { get; private set; }
        public bool CanProvideSupport => !IsReleased && !IsCollapseScheduled;

        private void Awake()
        {
            CacheReferences();
            IsReleased = _rigidbody.constraints != RigidbodyConstraints.FreezeAll;
        }

        private void Reset()
        {
            _controller = GetComponentInParent<LocalizedFractureController>();
            CacheReferences();
        }

        private void OnCollisionEnter(Collision collision)
        {
            if (IsReleased || _controller == null)
            {
                return;
            }

            _controller.TryApplyImpact(this, collision);
        }

        public void Initialize(LocalizedFractureController controller)
        {
            _controller = controller;
            CacheReferences();
            IsReleased = _rigidbody.constraints != RigidbodyConstraints.FreezeAll;
        }

        public void Release(Vector3 impulse, Vector3 impactPoint)
        {
            if (IsReleased)
            {
                return;
            }

            IsReleased = true;
            IsCollapseScheduled = false;
            _rigidbody.constraints = RigidbodyConstraints.None;
            _rigidbody.WakeUp();
            _rigidbody.AddForceAtPosition(impulse, impactPoint, ForceMode.Impulse);
        }

        public void ConfigureSupport(bool isAnchor)
        {
            _isAnchor = isAnchor;
            _neighbors.Clear();
        }

        public void AddNeighbor(LocalizedFracturePiece neighbor)
        {
            if (neighbor == null || neighbor == this || _neighbors.Contains(neighbor))
            {
                return;
            }

            _neighbors.Add(neighbor);
        }

        public bool ScheduleCollapse()
        {
            if (IsReleased || IsCollapseScheduled)
            {
                return false;
            }

            IsCollapseScheduled = true;
            return true;
        }

        public void CancelScheduledCollapse()
        {
            if (!IsReleased)
            {
                IsCollapseScheduled = false;
            }
        }

        private void CacheReferences()
        {
            if (_rigidbody == null)
            {
                _rigidbody = GetComponent<Rigidbody>();
            }

            if (_fragmentCollider == null)
            {
                _fragmentCollider = GetComponent<Collider>();
            }
        }
    }
}
