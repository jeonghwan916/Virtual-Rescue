# Breakable Partition Toolkit

OpenFracture를 기반으로 얇은 벽과 경량 칸막이에 국소 파괴와 지지 연결 그래프를 적용하는 Unity 6 패키지입니다.

패키지에 포함된 데모 재질과 씬은 Universal Render Pipeline 17.3.0을 기준으로 합니다.

## 설치

Unity Package Manager에서 **Add package from disk**를 선택하고 이 폴더의 `package.json`을 지정합니다.

## 파편 생성

1. 대상 오브젝트에 `MeshFilter`, `MeshRenderer`, `Collider`, `Rigidbody`를 준비합니다.
2. `BreakablePartitionAuthoring` 컴포넌트를 추가합니다.
3. 칸막이의 로컬 X/Y 방향에 맞춰 파쇄 축과 프레임 앵커를 설정합니다.
4. Inspector에서 **Generate / Rebuild Fragments**를 실행합니다.
5. 생성 결과를 프리팹으로 사용할 경우 `Save Fragment Meshes`를 활성화합니다.

생성된 파편 메시는 패키지가 아니라 현재 프로젝트의 기본 경로인 `Assets/Generated/BreakablePartitions`에 저장됩니다. 모델마다 파편 형상이 다르므로 이 생성물은 사용하는 프로젝트가 소유합니다.

## 런타임 구성

- `LocalizedFractureController`: 충돌 지점 반경 안의 파편을 해제하고 충격량을 적용합니다.
- `LocalizedFracturePiece`: 각 파편의 물리 상태와 연결 관계를 관리합니다.
- `FractureSupportGraph`: 프레임 앵커와 연결되지 않은 파편을 찾아 지연 붕괴시킵니다.

그래프 생성은 Authoring 시점에 수행됩니다. 런타임에는 타격 후 연결 탐색만 수행하므로 파편 수는 VR 목표 기기의 성능 예산에 맞춰 조절해야 합니다.

## 타격 필터

`Allowed Tag`가 비어 있으면 모든 충돌체를 허용합니다. 값을 지정하면 프로젝트의 Tag Manager에 같은 태그가 있어야 합니다. 데모의 기본값은 `Projectile`입니다.

## Third-party

OpenFracture 원본 라이선스와 변경 이력은 `LICENSE.md`, `THIRD_PARTY_NOTICES.md`, `Documentation~/OpenFracture-README.md`에서 확인할 수 있습니다.
