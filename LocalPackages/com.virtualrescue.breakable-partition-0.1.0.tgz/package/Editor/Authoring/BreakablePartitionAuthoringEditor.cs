using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VirtualRescue.Destruction;

namespace VirtualRescue.Editor
{
    [CustomEditor(typeof(BreakablePartitionAuthoring))]
    public sealed class BreakablePartitionAuthoringEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            EditorGUILayout.Space();

            var authoring = (BreakablePartitionAuthoring)target;
            using (new EditorGUI.DisabledScope(Application.isPlaying))
            {
                if (GUILayout.Button("Generate / Rebuild Fragments"))
                {
                    Generate(authoring);
                }

                if (GUILayout.Button("Clear Generated Fragments"))
                {
                    ClearGeneratedFragments(authoring);
                }
            }
        }

        private static void Generate(BreakablePartitionAuthoring authoring)
        {
            if (!ValidateSource(authoring, out string validationMessage))
            {
                Debug.LogError(validationMessage, authoring);
                return;
            }

            if (authoring.SaveFragmentMeshes &&
                !TryEnsureAssetFolder(authoring.MeshOutputFolder, out string folderMessage))
            {
                Debug.LogError(folderMessage, authoring);
                return;
            }

            ClearGeneratedFragments(authoring);
            GameObject source = authoring.gameObject;
            source.SetActive(true);

            Prefracture prefracture = source.GetComponent<Prefracture>();
            if (prefracture == null)
            {
                prefracture = Undo.AddComponent<Prefracture>(source);
            }

            prefracture.triggerOptions = new TriggerOptions
            {
                triggerType = TriggerType.Collision,
                minimumCollisionForce = authoring.MinimumCollisionForce,
                filterCollisionsByTag = !string.IsNullOrWhiteSpace(authoring.AllowedTag),
                triggerAllowedTags = string.IsNullOrWhiteSpace(authoring.AllowedTag)
                    ? new List<string>()
                    : new List<string> { authoring.AllowedTag },
                triggerKey = KeyCode.None
            };

            prefracture.fractureOptions = new FractureOptions
            {
                fragmentCount = authoring.FragmentCount,
                xAxis = authoring.FractureXAxis,
                yAxis = authoring.FractureYAxis,
                zAxis = authoring.FractureZAxis,
                detectFloatingFragments = authoring.DetectFloatingFragments,
                asynchronous = false,
                insideMaterial = authoring.InsideMaterial,
                textureScale = authoring.TextureScale,
                textureOffset = authoring.TextureOffset
            };

            prefracture.callbackOptions = new CallbackOptions();
            prefracture.prefractureOptions = new PrefractureOptions
            {
                unfreezeAll = false,
                saveFragmentsToDisk = authoring.SaveFragmentMeshes,
                saveLocation = authoring.MeshOutputFolder
            };

            EditorUtility.SetDirty(prefracture);
            prefracture.ComputeFracture();

            GameObject generatedRoot = FindGeneratedRoot(authoring);
            if (generatedRoot == null)
            {
                source.SetActive(true);
                Debug.LogError("OpenFracture did not create a fragment root.", authoring);
                return;
            }

            ConfigureLocalizedDestruction(generatedRoot, authoring);
            authoring.SetGeneratedRoot(generatedRoot);

            EditorUtility.SetDirty(authoring);
            EditorUtility.SetDirty(generatedRoot);
            EditorSceneManager.MarkSceneDirty(source.scene);
            AssetDatabase.SaveAssets();

            Selection.activeGameObject = generatedRoot;
            Debug.Log(
                $"Generated {generatedRoot.GetComponentsInChildren<LocalizedFracturePiece>(true).Length} " +
                $"breakable partition fragments for '{source.name}'.",
                generatedRoot);
        }

        private static void ConfigureLocalizedDestruction(
            GameObject generatedRoot,
            BreakablePartitionAuthoring authoring)
        {
            foreach (UnfreezeFragment legacyComponent in
                     generatedRoot.GetComponentsInChildren<UnfreezeFragment>(true))
            {
                Undo.DestroyObjectImmediate(legacyComponent);
            }

            LocalizedFractureController controller =
                generatedRoot.GetComponent<LocalizedFractureController>();
            if (controller == null)
            {
                controller = Undo.AddComponent<LocalizedFractureController>(generatedRoot);
            }

            foreach (Rigidbody fragmentRigidbody in
                     generatedRoot.GetComponentsInChildren<Rigidbody>(true))
            {
                fragmentRigidbody.constraints = RigidbodyConstraints.FreezeAll;

                LocalizedFracturePiece piece =
                    fragmentRigidbody.GetComponent<LocalizedFracturePiece>();
                if (piece == null)
                {
                    piece = Undo.AddComponent<LocalizedFracturePiece>(fragmentRigidbody.gameObject);
                }

                piece.Initialize(controller);
                EditorUtility.SetDirty(fragmentRigidbody);
                EditorUtility.SetDirty(piece);
            }

            controller.Configure(
                authoring.AllowedTag,
                authoring.DestructionRadius,
                authoring.DirectHitRadius,
                authoring.ImpulseMultiplier,
                authoring.MinimumCollisionForce,
                authoring.ImpactCooldown);
            controller.RefreshPieces();

            FractureSupportGraph supportGraph = generatedRoot.GetComponent<FractureSupportGraph>();
            if (supportGraph == null)
            {
                supportGraph = Undo.AddComponent<FractureSupportGraph>(generatedRoot);
            }

            supportGraph.Configure(
                authoring.VertexTolerance,
                authoring.MinimumSharedVertices,
                authoring.AnchorMargin,
                authoring.AnchorLeft,
                authoring.AnchorRight,
                authoring.AnchorTop,
                authoring.AnchorBottom,
                authoring.CollapseDelay,
                authoring.RandomCollapseDelay,
                authoring.DownwardImpulse);
            supportGraph.BuildGraph();

            EditorUtility.SetDirty(controller);
            EditorUtility.SetDirty(supportGraph);
        }

        private static void ClearGeneratedFragments(BreakablePartitionAuthoring authoring)
        {
            GameObject generatedRoot = authoring.GeneratedRoot;
            if (generatedRoot == null)
            {
                generatedRoot = FindGeneratedRoot(authoring);
            }

            if (generatedRoot != null)
            {
                Undo.DestroyObjectImmediate(generatedRoot);
            }

            authoring.SetGeneratedRoot(null);
            authoring.gameObject.SetActive(true);
            EditorUtility.SetDirty(authoring);
            EditorSceneManager.MarkSceneDirty(authoring.gameObject.scene);
        }

        private static GameObject FindGeneratedRoot(BreakablePartitionAuthoring authoring)
        {
            Transform parent = authoring.transform.parent;
            string generatedName = $"{authoring.name}Fragments";

            if (parent != null)
            {
                Transform child = parent.Find(generatedName);
                return child != null ? child.gameObject : null;
            }

            foreach (GameObject rootObject in authoring.gameObject.scene.GetRootGameObjects())
            {
                if (rootObject != authoring.gameObject && rootObject.name == generatedName)
                {
                    return rootObject;
                }
            }

            return null;
        }

        private static bool ValidateSource(
            BreakablePartitionAuthoring authoring,
            out string message)
        {
            if (authoring.GetComponent<MeshFilter>()?.sharedMesh == null)
            {
                message = "A source MeshFilter with a mesh is required.";
                return false;
            }

            if (authoring.GetComponent<MeshRenderer>() == null)
            {
                message = "A source MeshRenderer is required.";
                return false;
            }

            if (authoring.GetComponent<Collider>() == null)
            {
                message = "A source Collider is required.";
                return false;
            }

            if (authoring.GetComponent<Rigidbody>() == null)
            {
                message = "A source Rigidbody is required.";
                return false;
            }

            if (!authoring.FractureXAxis && !authoring.FractureYAxis && !authoring.FractureZAxis)
            {
                message = "Enable at least one fracture axis.";
                return false;
            }

            message = string.Empty;
            return true;
        }

        private static bool TryEnsureAssetFolder(string folderPath, out string message)
        {
            string normalizedPath = folderPath?.Replace('\\', '/').TrimEnd('/');
            if (string.IsNullOrWhiteSpace(normalizedPath) ||
                (normalizedPath != "Assets" && !normalizedPath.StartsWith("Assets/")))
            {
                message = "Mesh Output Folder must be inside the project's Assets folder.";
                return false;
            }

            string[] pathParts = normalizedPath.Split('/');
            string currentPath = pathParts[0];
            for (int i = 1; i < pathParts.Length; i++)
            {
                string nextPath = $"{currentPath}/{pathParts[i]}";
                if (!AssetDatabase.IsValidFolder(nextPath))
                {
                    AssetDatabase.CreateFolder(currentPath, pathParts[i]);
                }

                currentPath = nextPath;
            }

            message = string.Empty;
            return true;
        }
    }
}
