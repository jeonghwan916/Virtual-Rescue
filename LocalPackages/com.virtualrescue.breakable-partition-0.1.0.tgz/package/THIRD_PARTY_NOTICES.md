# Third-party notices

## OpenFracture

This package includes and modifies OpenFracture 1.0.2.

Copyright (c) 2021 Daniel Greenheck

OpenFracture is distributed under the MIT License. The original license text is preserved in `LICENSE.md`. The upstream project is available at <https://github.com/dgreenheck/OpenFracture>.

Local modifications include Unity 6 Rigidbody API compatibility and integration with localized destruction and support graph authoring.
